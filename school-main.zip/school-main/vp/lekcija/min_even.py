import random

numbers = [random.randint(-100, 100) for x in range(20)]

