from random import randint
numbers = [randint(-100, 100) for x in range(20)]

print(numbers)
print(min(numbers) + max(numbers))

# lorem ipsum
# generator na bytove, dumi i spisaci